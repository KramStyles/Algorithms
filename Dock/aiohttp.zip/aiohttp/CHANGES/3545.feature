Drop custom router support
